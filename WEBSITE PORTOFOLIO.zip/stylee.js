function tekan() 
{ 
 var jurusanstr = (document.fform.Jurusan.value); 
 document.fform.Ojurusan.value = jurusanstr; 
} 